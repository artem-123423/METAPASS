'use client';

import React from 'react'

const XBtn = () => {


  return (
		<div>
			<button
				className='x-btn'
				onClick={() => window.open('https://x.com/7MetaPass7', '_blank')}
			></button>
		</div>
	)
}

export default XBtn
