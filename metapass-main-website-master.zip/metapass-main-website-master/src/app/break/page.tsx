import './page.css';

export default function Page() {
  return (
    <main className="container">
        <div className="bg-gradient blur1"></div>
      <div className="bg-gradient blur2"></div>
      <div className="bg-gradient blur3"></div>
      <div className="bg-gradient blur4"></div>
      <div className="bg-gradient blur5"></div>
      <div className="text">
        <h1>technical break :( <span className="sad-face"></span></h1>
      </div>
      <img src="images\phone_icon.png" alt="" />
      <div className="image">

      </div>
    </main>
  );
}
